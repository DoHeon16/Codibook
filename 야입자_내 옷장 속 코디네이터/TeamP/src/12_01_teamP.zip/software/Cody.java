package software;

import java.util.ArrayList;
import java.util.Random;

public class Cody {

	public Cody(double temperature) {
		txtTrans txt = new txtTrans();
		ArrayList<CCodi> cody0609 = txt.CCodiDB;
		//CCodi �ȿ� String[] clotheList 
		User user1 = new User("NoName");
		ColorMatch cMatch = new ColorMatch();
	//	CType ctype = new CType();
		Random rand = new Random();
		int isDone = 0;
		String[] temp = new String[4];
		if(0<=temperature&&temperature<=5) {
			
		}
		else if(5<temperature&&temperature<=9) {
			while(true) {
				while(true) {
					int random=rand.nextInt(cody0609.size());
					for(int j=0; j<4; j++) {
						temp[j]=cody0609.get(random).clotheList[j];
						if(user1.closet.contains(new Clothe(temp[j]))) {
							continue;
						}
						else {
							isDone=1;
							break;
						}
					}
					if(isDone==1)
						continue;
					else {
						isDone=0;
						break;
					}

				}
				int[] colors = new int[4];
				Clothe[] temp1 = new Clothe[4];
				for(int i=0; i<4; i++) {
					for(int j=0; j<user1.closet.size(); j++) {
						if(user1.closet.get(j).getSort().equals(temp[i])) {
							temp1[i]=user1.closet.get(j);
							colors[i]=user1.closet.get(j).getColor();
							break;
						}
						else
							continue;
					}
				}
				if(cMatch.colorMatch(colors[0],colors[1], colors[2], colors[3])) {
					System.out.println("�� �� ������ ������");
					break;
				}
				else
					continue;
			}
			
			
			
			
		}
		
	}
	
	
	
}
