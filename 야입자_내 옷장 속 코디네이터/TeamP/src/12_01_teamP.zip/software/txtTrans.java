package software;

public class txtTrans {

}
