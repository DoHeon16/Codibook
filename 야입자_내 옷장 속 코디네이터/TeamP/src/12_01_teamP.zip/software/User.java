package software;

import java.util.ArrayList;
import java.util.Scanner;

public class User {

	Scanner scan = new Scanner(System.in);
	String name;
	ArrayList<Clothe> closet;
	
	public User(String name) {
		closet = new ArrayList<Clothe>();
	}
	
	public void addClothe() {
		System.out.println("�� ����");
		int a, b, c;
		a=scan.nextInt();
		System.out.println("�� ���� ���� ");
		c=scan.nextInt();
		System.out.println("����");
		b=scan.nextInt();
		Clothe clothe = new Clothe(a, c, b);
		closet.add(clothe);
	}
	//�׽�Ʈ��
	public void addClothe(int sort) {
		closet.add(new Clothe(sort));
	}
}
