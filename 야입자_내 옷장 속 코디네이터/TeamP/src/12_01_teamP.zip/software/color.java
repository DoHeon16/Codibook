package software;

import java.util.ArrayList;

public class color {

	ArrayList<color> set = new ArrayList<color>();
	
	public Integer[] temp = new Integer[4];
	
	
	
}
