package software;

public class Clothe {

	int sort;
	int index;
	int color;
	
	public Clothe(int sort) {
		this.sort=sort;
		index=-1;
		color=-1;
	}
	public Clothe(int sort, int index, int color) {
		this.sort=sort;
		this.index=index;
		this.color=color;
	}
	public int getSort() {
		return sort;
	}
	public void setSort(int sort) {
		this.sort = sort;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public int getColor() {
		return color;
	}
	public void setColor(int color) {
		this.color = color;
	}
	
}
