package software;

import java.awt.Color;
import java.util.ArrayList;

public class ColorMatch {

	//���� R,G,B���� �������� �Լ�
	public int getR(int color) {
		return color/0xF0000;
	}
	public int getG(int color) {
		return color/0xF00%0xF00;
	}
	public int getB(int color) {
		return color%0xF00;
	}
	
	//���� �������� ��ȯ
	public int toSafeColor(int color) {
		int r, g, b;
		r=getR(color);
		g=getG(color);
		b=getB(color);
		
		if(0<=r&&r<0x22)
			r=0;
		else if(0x22<=r&&r<=0x55)
			r=0x33;
		else if(0x55<=r&&r<=0x88)
			r=0x66;
		else if(0x88<=r&&r<=0xBB)
			r=0x99;
		else if(0xBB<=r&&r<=0xEE)
			r=0xCC;
		else
			r=0xFF;
		
		if(0<=g&&g<0x22)
			g=0;
		else if(0x22<=g&&g<=0x55)
			g=0x33;
		else if(0x55<=g&&g<=0x88)
			g=0x66;
		else if(0x88<=g&&g<=0xBB)
			g=0x99;
		else if(0xBB<=g&&g<=0xEE)
			g=0xCC;
		else
			g=0xFF;
		
		if(0<=b&&b<0x22)
			b=0;
		else if(0x22<=b&&b<=0x55)
			b=0x33;
		else if(0x55<=b&&b<=0x88)
			b=0x66;
		else if(0x88<=b&&b<=0xBB)
			b=0x99;
		else if(0xBB<=b&&b<=0xEE)
			b=0xCC;
		else
			b=0xFF;
		
		return r*0xF0000+g*0xF00+b;
	}
	
	//���� �������� Ȯ���ϴ� �Լ�
	public boolean isSameColor(int color1, int color2) {
		if(getR(color1)==getR(color2)&&getG(color1)==getG(color2))
			return true;
		else if(getR(color1)==getR(color2)&&getB(color1)==getB(color2))
			return true;
		else if(getG(color1)==getG(color2)&&getB(color1)==getB(color2))
			return true;
		else
			return false;
	}
	
	public int BofColor(int color) {
		return (getR(color)+getG(color)+getB(color))/3;
	}
	
	//���� �������� Ȯ���ϴ� �Լ�
	public boolean isSameB(int color1, int color2) {
		
		if(BofColor(color1)==BofColor(color2))
			return true;
		else
			return false;
	}
	
	//���� ä������ Ȯ���ϴ� �Լ�
	public boolean isSameS(int color1, int color2) {

		Color color = new Color(color1);
		Color color_ = new Color(color2);
		float[] temp = new float[3];
		float[] temp_ = new float[3];
		
		Color.RGBtoHSB(getR(color1), getG(color1), getB(color1), temp);
		Color.RGBtoHSB(color_.getRed(), color_.getGreen(), color_.getBlue(), temp_);
		if(temp[1]==temp_[1])
			return true;
		else
			return false;
		
		
	}
	//��ä������ �Ǻ�
	public boolean isAchro(int color) {
		Color color1 = new Color(color);
		float[] temp = new float[3];
		color1.getColorComponents(temp);
		for(int i=0; i<2; i++) {
			if(temp[i]==temp[i+1]) {
				continue;
			}
			else {
				return false;
			}
		}
		return true;
	}
	
	//���� ä�� ���� �����ϴ� �Լ���
	public int downB(int color) {
		int temp = color-0x333333;
		if((getR(color)>=getG(color))&&(getR(color)>=getB(color))) {
			if(getR(temp)==getR(color))
				return temp;
			else
				return color;
		}
		else if((getG(color)>=getR(color))&&(getG(color)>=getB(color))) {
			if(getG(temp)==getG(color))
				return temp;
			else
				return color;
		}
		else if((getB(color)>=getG(color))&&(getB(color)>=getR(color))) {
			if(getB(color)==getB(temp))
				return temp;
			else
				return color;
		}
		else
			return color;
	
		
	}
	
	public int upB(int color) {
		int temp = color+0x333333;
		if((getR(color)>=getG(color))&&(getR(color)>=getB(color))) {
			if(getR(temp)==getR(color))
				return temp;
			else
				return color;
		}
		else if((getG(color)>=getR(color))&&(getG(color)>=getB(color))) {
			if(getG(temp)==getG(color))
				return temp;
			else
				return color;
		}
		else if((getB(color)>=getG(color))&&(getB(color)>=getR(color))) {
			if(getB(color)==getB(temp))
				return temp;
			else
				return color;
		}
		else
			return color;
		
	
	}
	
	public int upS(int color) {
		if((getR(color)>=getG(color))&&(getR(color)>=getB(color))) {
			return color-0x003333;
		}
		else if((getG(color)>=getR(color))&&(getG(color)>=getB(color))) {
			return color-0x330033;
		}
		else if((getB(color)>=getG(color))&&(getB(color)>=getR(color))) {
			return color-0x333300;
		}
		else
			return color;
	}
	
	public int downS(int color) {
		if((getR(color)>=getG(color))&&(getR(color)>=getB(color))) {
			return color+0x003333;
		}
		else if((getG(color)>=getR(color))&&(getG(color)>=getB(color))) {
			return color+0x330033;
		}
		else if((getB(color)>=getG(color))&&(getB(color)>=getR(color))) {
			return color+0x333300;
		}
		else
			return color;
	}
	
	public int upH(int color) {
		if((getR(color)>=getG(color))&&(getR(color)>=getB(color))) {
			return color+0x330000;
		}
		else if((getG(color)>=getR(color))&&(getG(color)>=getB(color))) {
			return color+0x003300;
		}
		else if((getB(color)>=getG(color))&&(getB(color)>=getR(color))) {
			return color+0x000033;
		}
		else
			return color;
	}
	
	public int downH(int color) {
		if((getR(color)>=getG(color))&&(getR(color)>=getB(color))) {
			return color-0x330000;
		}
		else if((getG(color)>=getR(color))&&(getG(color)>=getB(color))) {
			return color-0x003300;
		}
		else if((getB(color)>=getG(color))&&(getB(color)>=getR(color))) {
			return color-0x000033;
		}
		else
			return color;
	}
	
	
	
	public boolean tonONton(int a, int b, int c, int d) {
	//���� ���� ������ ä���� �ٸ��� ���
		int tmp[] = new int[4];
		tmp[0]=a;
		tmp[1]=b;
		tmp[2]=c;
		tmp[3]=d;
		ArrayList<Integer> temp = new ArrayList<Integer>();
		
		for(int i=0; i<4; i++) {
			if(tmp[i]!=0xFFFFFF&&tmp[i]!=0x000000) {
				temp.add(tmp[i]);
			}
		}
		
		for(int j=0; j<temp.size()-1; j++) {
			if(isSameColor(temp.get(j), temp.get(j+1))) {
				continue;
			}
			else
				return false;
		}
		for(int k=0; k<temp.size()-1; k++) {
			if(!isSameB(temp.get(k), temp.get(k+1)))
				continue;
			else
				return false;
		}
		for(int z=0; z<temp.size()-1; z++) {
			if(!isSameS(temp.get(z), temp.get(z+1)))
				continue;
			else
				return false;
		}
		
		return true;
	}
	
	public boolean tonINton(int a, int b, int c, int d) {
	//���� ������ ä���� ���� �޸��ؼ� ���
		
		ArrayList<Integer> temp = new ArrayList<Integer>();
		if(a==0x000000||a==0xFFFFFF)
			temp.add(a);
		if(b==0x000000||b==0xFFFFFF)
			temp.add(b);
		if(c==0x000000||c==0xFFFFFF)
			temp.add(c);
		if(d==0x000000||d==0xFFFFFF)
			temp.add(d);
		
		for(int i=0; i<temp.size()-1; i++) {
			if(isSameS(temp.get(i), temp.get(i+1))==true)
				continue;
			else {
				return false;
			}		
		}
		return true;
	}
	
	//�ƴ� ��¥ �̰� ��� �����ؾߵ��� ���� �ȿ�.....
/*	public boolean Gradation(int a, int b, int c, int d) {
		//���� �迭 ������ ������ ä���� ���� ���������� ��ġ 
		
		return false;
	}*/
	
	public boolean Seperation(int a, int b, int c, int d) {
		//������ ��ä�� ��� ���� ��ä���̳� �߰��� �ϳ�
		ArrayList<Integer> temp = new ArrayList<Integer>();//��ä�� ����
		ArrayList<Integer> temp2 = new ArrayList<Integer>();//��ä�� ����
		if(!isAchro(a))
			temp.add(a);
		else
			temp2.add(a);

		if(!isAchro(b))
			temp.add(b);
		else
			temp2.add(b);
		
		if(!isAchro(c))
			temp.add(c);
		else
			temp2.add(c);
		
		if(!isAchro(d))
			temp.add(d);
		else
			temp2.add(d);
		
		if(temp2.size()==1) {
				temp2.add(0xFFFFFF);
				if(tonONton(temp2.get(0), temp2.get(1), temp2.get(2), temp2.get(3)))
					return true;
				if(tonINton(temp2.get(0), temp2.get(1), temp2.get(2), temp2.get(3)))
					return true;
				else
					return false;//���� �ڿ� �� �߰��ؾߵ�!!!!!!!
		}
		else
			return false;
		
	}
	
	public boolean Accent(int a, int b, int c, int d) {
		//��ü������ �����ο� �ڵ���̼� ��(��ä���� ����)�� �Ǽ�Ʈ Į�� �ϳ�
		ArrayList<Integer> temp = new ArrayList<Integer>();
		ArrayList<Integer> temp2 = new ArrayList<Integer>();
		if(isAchro(a))
			temp.add(a);
		else
			temp2.add(a);

		if(isAchro(b))
			temp.add(b);
		else
			temp2.add(b);
		
		if(isAchro(c))
			temp.add(c);
		else
			temp2.add(c);
		
		if(isAchro(d))
			temp.add(d);
		else
			temp2.add(d);
		
		if(temp.size()<3) {
			if(temp2.size()==1)
				return true;
			else {
				for(int i=0; i<temp2.size()-1; i++) {
					if(isSameColor(temp2.get(i), temp2.get(i+1)))
						continue;
					else {
						return false;
					}
				}
				return true;
			}
			
		}
		else 
			return true;//�˴� ��ä���� ��� �ϴ� �𸣰ڰ� true��� ����
		
		
	}
	
	public int[] showSimilars1(int color) {
		int temp[] =new int[5];
	
	//	while(upB(color)<0xFFFFFF&&upB(color)>0x000000) {
		//	color=upB(color);
			//System.out.println(color);
	//	}
		for(int i=0; i<5; i++) {
			temp[i]=color;
			System.out.println(color);
			color=downB(color);
		}
		return temp;
		
	}
	
	public int[] showSimilars2(int color) {
		int temp[] = new int[5];
		temp[3]=color-0x330000;
		temp[1]=color+0x33;
		temp[2]=color;
		temp[4]=color-0x33;
		temp[0]=color+0x330000;
		
		return temp;
	}
	
	public boolean colorMatch(int a, int b, int c, int d) {
		
		if(tonONton(a, b, c, d))
			return true;
		if(tonINton(a, b, c, d))
			return true;
		if(Accent(a, b, c, d))
			return true;
		if(Seperation(a, b, c, d))
			return true;
		else
			return false;
		
	}
	
}
